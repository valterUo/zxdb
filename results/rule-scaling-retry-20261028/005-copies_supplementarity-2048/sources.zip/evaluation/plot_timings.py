"""Generate paper-style TikZ/PGFPlots figures from one timings.csv (stdlib only)."""
import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path
from statistics import geometric_mean


ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / 'results/rerun-20261028/performance/timings.csv'
ENGINES = {
    'pyzx': ('PyZX', 'black', '*', 'solid'),
    'cypher': ('Cypher', 'blue!70!black', 'square*', 'dashed'),
    'hybrid': ('Cypher+C++', 'orange!85!black', 'triangle*', 'dashdotted'),
}
NAMES = {
    'pivot': 'Pivot', 'pivot_gadget': 'Gadget pivot',
    'lcomp': 'Local complementation', 'gadget_fusion': 'Phase-gadget fusion',
    'spider_fusion': 'Spider fusion', 'identity': 'Identity removal',
    'bialgebra': 'Bialgebra', 'pivot_boundary': 'Boundary pivot',
    'hadamard_cancel': 'Hadamard cancellation', 'copy': 'Copy',
    'supplementarity': 'Supplementarity', 'identity_chain': 'Identity chain',
    'random_clifford': 'Clifford', 'random_clifford_t': 'Clifford+T',
    'random_t_heavy': 'T-heavy', 'layered_local': 'Local layered',
    'layered_global': 'Global layered',
}


def value(row, engine, scope, speedup=False):
    """Never turn failed, missing, nonpositive, or no-op ratios into wins."""
    required = (engine, 'pyzx') if speedup else (engine,)
    for name in required:
        if row[name + '_complete'] != 'True':
            return None
        if speedup and row[name + '_active'] != 'True':
            return None
    try:
        result = float(row[engine + '_' + scope])
        if speedup:
            baseline = float(row['pyzx_' + scope])
            if not math.isfinite(baseline) or baseline <= 0:
                return None
            result = baseline / result
        return result if math.isfinite(result) and result > 0 else None
    except (ValueError, ZeroDivisionError):
        return None


def summarize(rows, engine, scope, speedup=False):
    values = [value(r, engine, scope, speedup) for r in rows]
    # Require the entire group; do not silently summarize only survivors.
    if any(v is None for v in values):
        return None
    return geometric_mean(values), min(values), max(values)


def figure(rows, families, scope, kind, speedup=False):
    columns = 3 if kind == 'circuits' else 4
    width, height = ('.29', '.22') if columns == 3 else ('.215', '.17')
    ylabel = 'PyZX / database' if speedup else 'Time (s)'
    lines = [r'\begin{tikzpicture}',
             r'\begin{groupplot}[group style={group size=' +
             f'{columns} by {math.ceil(len(families)/columns)},' +
             r'horizontal sep=1.6cm,vertical sep=2cm},',
             f'width={width}\\textwidth,height={height}\\textwidth,',
             r'xmode=log,ymode=log,log basis x=2,',
             r'tick label style={font=\scriptsize},label style={font=\scriptsize},',
             r'title style={font=\small},grid=major,grid style={black!10},',
             r'axis lines=left,legend columns=-1,',
             r'legend style={font=\scriptsize,draw=none,at={(0,1.5)},anchor=south west},',
             r'unbounded coords=jump]']
    engines = list(ENGINES)[1:] if speedup else list(ENGINES)
    for index, family in enumerate(families):
        selected = [r for r in rows if r['family'] == family]
        grouped = defaultdict(list)
        for row in selected:
            grouped[int(row['size'])].append(row)
        xlabel = {'circuits': 'Qubits', 'copies': 'Disjoint copies',
                  'rules': 'Input vertices'}[kind]
        title = NAMES[family.removeprefix('copies_')]
        lines.append(f'\\nextgroupplot[title={{{title}}},xlabel={{{xlabel}}},ylabel={{{ylabel}}}]')
        xs = []
        for engine in engines:
            label, color, marker, style = ENGINES[engine]
            coordinates = []
            for size, group in sorted(grouped.items()):
                # Rule panels use actual graph size, not a synthetic "qubit" label.
                x = int(group[0]['vertices']) if kind == 'rules' else size
                if kind == 'rules' and len({r['vertices'] for r in group}) != 1:
                    raise ValueError(f'Inconsistent vertex counts: {family}, {size}')
                xs.append(x)
                summary = summarize(group, engine, scope, speedup)
                if summary is None:
                    coordinates.append(f'({x},nan)')
                    print(f'Omitted incomplete/invalid cell: {family}, {size}, {engine}, {scope}')
                else:
                    center, low, high = summary
                    coordinates.append(f'({x},{center:.9g}) += (0,{high-center:.9g}) -= (0,{center-low:.9g})')
            lines.append(r'\addplot+[' + f'color={color},mark={marker},{style},' +
                         r'line width=.7pt,mark size=1.5pt,error bars/.cd,y dir=both,y explicit] coordinates {' +
                         '\n' + '\n'.join(coordinates) + '\n};')
            if index == 0:
                lines.append(f'\\addlegendentry{{{label}}}')
        if speedup:
            lines.append(r'\addplot[gray,densely dotted,no marks,forget plot] coordinates {' +
                         f'({min(xs)},1) ({max(xs)},1)' + '};')
    return '\n'.join(lines + [r'\end{groupplot}', r'\end{tikzpicture}', ''])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv', nargs='?', type=Path, default=DEFAULT)
    parser.add_argument('--output', type=Path, help='Default: figures beside the CSV')
    args = parser.parse_args()
    with args.csv.open(newline='', encoding='utf-8-sig') as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        parser.error('The timing CSV is empty')
    present = {r['family'] for r in rows}
    known = set(NAMES) | {'copies_' + f for f in NAMES}
    if present - known:
        parser.error(f'Unknown families: {sorted(present - known)}')
    groups = {
        'rules': [f for f in NAMES if f in present and not f.startswith(('random_', 'layered_'))],
        'copies': ['copies_' + f for f in NAMES if 'copies_' + f in present],
        'circuits': [f for f in NAMES if f in present and f.startswith(('random_', 'layered_'))],
    }
    output = args.output or args.csv.parent / 'figures'
    output.mkdir(parents=True, exist_ok=True)
    document = [r'\documentclass{article}', r'\usepackage[a4paper,margin=1cm]{geometry}',
                r'\usepackage{pgfplots}', r'\usepgfplotslibrary{groupplots}',
                r'\pgfplotsset{compat=1.18}', r'\pagestyle{empty}', r'\begin{document}']
    for kind, families in groups.items():
        if not families:
            continue
        for scope in ('rewrite', 'total'):
            for speedup in ((False, True) if kind == 'circuits' else (False,)):
                name = f'{kind}-{scope}' + ('-speedup' if speedup else '')
                path = output / (name + '.tex')
                path.write_text(figure(rows, families, scope, kind, speedup), encoding='utf-8')
                print(path)
                caption = ('Geometric mean of configuration medians; bars span their min--max, '
                           'not confidence intervals. Missing cells break curves. '
                           'Panels have independent axis limits. ')
                if kind == 'circuits':
                    caption += ('Local-layered seed labels repeat the same input. '
                                'Random depth = 20 times qubits; layered depth = 2. ')
                caption += ('Ratios above 1 favor the database. ' if speedup else '')
                caption += ('Rewrite excludes import/export.' if scope == 'rewrite' else
                            'Total includes in-memory import/export (PyZX: copying), not startup or disk I/O.')
                document += [r'\begin{center}', f'\\textbf{{{name}}}\\par\\medskip',
                             f'\\input{{{name}.tex}}', r'\end{center}', caption, r'\clearpage']
    document += [r'\end{document}', '']
    (output / 'main.tex').write_text('\n'.join(document), encoding='utf-8')
    print(f'{len(rows)} configurations; compile {output / "main.tex"}')


if __name__ == '__main__':
    main()
